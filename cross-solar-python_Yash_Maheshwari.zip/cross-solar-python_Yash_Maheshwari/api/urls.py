from django.urls import path

from . import views

urlpatterns = [
    # path(r'^panel/(?P<panelid>\d+)/analytics/$', views.HourAnalyticsView.as_view()),
    # path(r'^panel/(?P<panelid>\d+)/analytics/day/$', views.DayAnalyticsView.as_view()),

    path('panel/<panelid>/analytics/', views.HourAnalyticsView.as_view()),
    path('panel/<panelid>/analytics/day/', views.DayAnalyticsView.as_view()),
]

