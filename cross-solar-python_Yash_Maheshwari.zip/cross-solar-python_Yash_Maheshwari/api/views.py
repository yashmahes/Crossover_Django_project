from rest_framework import viewsets,status
from rest_framework.views import APIView, Response
from .models import Panel, OneHourElectricity
from .serializers import PanelSerializer, OneHourElectricitySerializer

class PanelViewSet(viewsets.ModelViewSet):
    queryset = Panel.objects.all()
    serializer_class = PanelSerializer

class HourAnalyticsView(APIView):
    serializer_class = OneHourElectricitySerializer
    def get(self, request, panelid):
        panelid = int(self.kwargs.get('panelid', 0))
        queryset = OneHourElectricity.objects.filter(panel_id=panelid)
        items = OneHourElectricitySerializer(queryset, many=True)
        return Response(items.data)
    def post(self, request, panelid):
        panelid = int(self.kwargs.get('panelid', 0))
        serializer = OneHourElectricitySerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class DayAnalyticsView(APIView):
    def get(self, request, panelid):
        # Please implement this method to return Panel's daily analytics data
        panelid = int(self.kwargs.get('panelid', 0))
        queryset = OneHourElectricity.objects.filter(panel_id=panelid).order_by("date_time")
        items = OneHourElectricitySerializer(queryset, many=True)
        the_data = items.data

        # getting the unique dates
        unique_dates = []
        for q in the_data:
            date = q["date_time"]
            date = date[: date.index("T")]

            if date not in unique_dates:
                unique_dates.append(date)
                

        the_response = []
        
        for date in unique_dates:
            the_sum = 0
            the_average = 0
            the_count = 0
            the_maximum = the_data[0]["kilo_watt"]
            the_minimum = the_data[0]["kilo_watt"]

            for q in the_data:
                if date in q["date_time"]:
                    the_count += 1
                    the_sum += q["kilo_watt"]

                    if q["kilo_watt"] > the_maximum:
                        the_maximum = q["kilo_watt"]

                    if q["kilo_watt"] < the_minimum:
                        the_minimum = q["kilo_watt"]

            the_average = the_sum / the_count  

            the_response.append({
                "date": date,
                "sum": the_sum,
                "average": the_average,
                "maximum": the_maximum,
                "minimum": the_minimum
            })        

        return Response(the_response)
